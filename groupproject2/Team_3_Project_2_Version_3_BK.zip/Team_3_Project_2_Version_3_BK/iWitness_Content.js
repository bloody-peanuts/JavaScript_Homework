//creates a status update
function statusUp(){
	var update = ("<p>"+retriever()+"</p>");
	appendFeed(update)
}

//creates an image update
function imageUp() {
	var update = retriever();
	//verification of supported image
	if ((update == "kittens.jpg") || (update == "sonic.png") || (update == "janitor.gif")){
		update = '<p><img src="'+update+'" height="150"></p>'
	}else{
		update = "<p>Image not found</p>"
	}
	appendFeed(update);
}

//creates a link update
function linkUp() {
	var update = retriever();
	update = ("<p><a href='"+update+"'>"+update+"</a></p>");
	appendFeed(update);
}

//append created update to top of feed
function appendFeed(update) {
	var feed = document.getElementById("feed");
	var newFeed = (update + feed.innerHTML);
	feed.innerHTML = newFeed;
}

//Object - Retriever puppy
//Fetches input from the form box, clears it, and brings it back
function retriever() {
	var status = document.getElementById("status");
	ball = status.value;
	status.value = "";
	return ball;
}